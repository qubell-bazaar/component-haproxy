default['haproxy']['stats_user'] = "admin"
default['haproxy']['stats_pass'] = "pa55w0rd"
default['haproxy']['stats_uri'] = "/admin?stats"
default['haproxy']['stats_port'] = "1926"
